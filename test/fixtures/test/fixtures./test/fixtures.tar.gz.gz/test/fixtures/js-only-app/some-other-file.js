var util = require('util');

module.exports = function(){
  console.log('hello from some other file!');
};
